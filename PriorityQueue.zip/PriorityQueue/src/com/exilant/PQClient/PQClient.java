package com.exilant.PQClient;

import java.util.Iterator;
import java.util.PriorityQueue;

import com.exilant.bean.Person;
import com.exilant.dao.Sorter;

public class PQClient {
	public static void main(String[] args) {
		System.out.println("Alphabetical order\n");
		PriorityQueue<Person> persons = new PriorityQueue<>(new Sorter().new SortOnName());
		persons.offer(new Person(1, "veda"));
		persons.offer(new Person(2, "varsha"));
		persons.offer(new Person(5, "lakshmi"));
		persons.offer(new Person(3, "swathi"));
		printPersons(persons);
		System.out.println("-----------------------------------");
		System.out.println("ID order\n");
		PriorityQueue<Person> persons1 = new PriorityQueue<>(new Sorter().new SortOnId());
		persons1.addAll(persons);
		printPersons(persons1);
		
	}

	static void printPersons(PriorityQueue<Person> persons) {
		Iterator<Person> itr = persons.iterator();
		while (itr.hasNext()) {
			System.out.println(itr.next());
		}
	}
}
