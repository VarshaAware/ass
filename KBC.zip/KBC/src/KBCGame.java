import java.io.IOException;
import java.io.InputStreamReader;
import java.io.LineNumberReader;

public class KBCGame {

	static LineNumberReader cin = new LineNumberReader(new InputStreamReader(System.in));

	public static void main(String[] args) {
		int score = 0;
		final int NumberofQuestions = 5;
		System.out.println("\n" + "\t\t\t******* KBC ******\n\n" + "" + "");
		// storing question(with options) as well as answer in 2-dimensional
		// array

		String[][] arr1 = {
				{ "\n In which year of First World War Germany declared war on Russia and France? \na. 1914 \nb. 1915 \nc. 1916 \nd. 1917",
						"a" },
				{ "\n ICAO stands for ? \na. International Civil Aviation Organization \nb. Indian Corporation of Agriculture Organization \nc. Institute of Company of Accounts Organization \nd. None of the above",
						"a" },
				{ "\n India has largest deposits of ____ in the world. ? \na. gold \nb. copper \nc. mica \nd. None of the above",
						"c" },
				{ "\n How many Lok Sabha seats belong to Rajasthan? \na. 32 \nb. 25 \nc. 30 \nd. 17 ", "b" },
				{ "\n India's first satellite is named after ? \na. Aryabhatta \nb. Bhaskara II  \nc. Bhaskara I \nd. Albert Einstein",
						"a" } };

		String[] ans = new String[NumberofQuestions];

		// going through all questions and compare it's answers)
		for (int x = 0; x < NumberofQuestions; x++) {
			System.out.print((x + 1) + ". " + arr1[x][0] + "   ");

			try {
				ans[x] = cin.readLine();
			} catch (IOException e) {
				System.err.println("Error.");
			}

			ans[x].toLowerCase();

			if (arr1[x][1].equals(ans[x])) {
				score++;
			}

			System.out.print("\n");

		}
		System.out.println("***** KBC Result *****");
		System.out.println("Total number of questions = " + NumberofQuestions);
		System.out.println("Number of right answers = " + score);
		System.out.println("result in percentage = " + 100 * score / NumberofQuestions + "%");

	
		System.exit(0);

	}

}