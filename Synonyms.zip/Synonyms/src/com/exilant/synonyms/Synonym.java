package com.exilant.synonyms;

import java.util.HashMap;
import java.util.Scanner;

public class Synonym {
	public static void main(String[] args) {
		HashMap<String, String[]> dictionary = new HashMap<>();
		dictionary.put("Amazing",new String[]{"incredible","unbelievable","improbable","fabulous", "wonderful", "fantastic"});
		dictionary.put("brave",new String[]{"courageous", "fearless"," dauntless","intrepid","plucky", "daring", "heroic"});
		dictionary.put("Idea",new String[]{"thought", "concept", "conception", "notion", "understanding", "opinion", "plan"});
		for(String key : dictionary.keySet()){
			System.out.println(key);
		}
		System.out.println("Enter the above words to find  synonyms");
		Scanner scanner = new Scanner(System.in);
		String word = scanner.next();
		
scanner.close();
		for(String key : dictionary.keySet()){
			
			if(key.equalsIgnoreCase(word)){
				for(String synonym : dictionary.get(key))
				System.out.print(synonym + " ");
				
			}
		}
	}
}
