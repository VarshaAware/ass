package com.exilant.controllers;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/CrudController")
public class CRUDController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	enum CRUD {
		insert("insert"), select("select"), update("update"), delete("delete");

		private String crud;

		private CRUD(String crud) {
			this.crud = crud;
		}

		public String getCrud() {
			return crud;
		}

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String crud = request.getParameter("crud");

		switch (CRUD.valueOf(crud)) {

		case insert:
			request.getRequestDispatcher("/views/InsertAndUpdate.jsp").include(request, response);
			break;
		case select:
			request.getRequestDispatcher("/views/UpdateAndDelete.jsp").include(request, response);
			break;
		case update:
			request.getRequestDispatcher("/views/UpdateAndDelete.jsp").include(request, response);
			break;
		case delete:
			request.getRequestDispatcher("/views/UpdateAndDelete.jsp").include(request, response);
			break;

		default:
			break;
		}

		out.close();
	}

}
