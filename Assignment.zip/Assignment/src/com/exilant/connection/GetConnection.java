package com.exilant.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class GetConnection {

	static Connection connection;
	public PreparedStatement preparedStatement = null, ps1 = null;
	public ResultSet rs = null;

	public static Connection getOracleConn() {

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");

			connection = DriverManager.getConnection("jdbc:oracle:thin:@10.2.0.28:1521:orcl", "Orclexi09", "Orclexi09");

			return connection;
		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;
	}

	public static Connection getMysqlConn() {

		return null;
	}
}
