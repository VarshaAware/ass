package com.exilant.dao;

import java.sql.SQLException;

import com.exilant.beans.Customer;
import com.exilant.connection.GetConnection;

public class CustomerDAO {
	public boolean insertCustomer(Customer cust) {
		String sql = "insert into Cust values(?,?,?,?,?)";
		GetConnection getConnection = new GetConnection();
		try {
			getConnection.preparedStatement = GetConnection.getOracleConn().prepareStatement(sql);
			getConnection.preparedStatement.setInt(1, cust.getCustId());
			getConnection.preparedStatement.setString(2,
					cust.getName().getFirstName() + " " + cust.getName().getLastName());
			getConnection.preparedStatement.setDouble(3, cust.getIncome());
			getConnection.preparedStatement.setString(4, cust.getAddr().gethNo() + "," + cust.getAddr().getStreet()
					+ "," + cust.getAddr().getCity() + cust.getAddr().getPin());
			getConnection.preparedStatement.setString(5, cust.getEmail());
			return getConnection.preparedStatement.executeUpdate() > 0;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				getConnection.preparedStatement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return false;

	}
}
